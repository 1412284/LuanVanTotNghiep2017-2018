By submitting a pull request, you represent that you have the right to license
your contribution to Marcin Krzyżanowski and the community, and agree by submitting the patch
that your contributions are licensed under the commercial licence.

---

Before submitting the pull request, please make sure you have tested your
changes.