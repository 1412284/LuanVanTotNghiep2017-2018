//
//  demoViewController.swift
//  demoApp
//
//  Created by CPU11197-local on 5/14/18.
//  Copyright © 2018 CPU11197-local. All rights reserved.
//

import UIKit

class demoViewController: UIViewController {
    
    
    @IBOutlet weak var btn0: UIButton!
    @IBOutlet weak var btn1: UIButton!
    @IBOutlet weak var btn2: UIButton!
    @IBOutlet weak var btn3: UIButton!
    @IBOutlet weak var btn4: UIButton!
    @IBOutlet weak var btn5: UIButton!
    @IBOutlet weak var btn6: UIButton!
    @IBOutlet weak var btn7: UIButton!
    @IBOutlet weak var btn8: UIButton!
    @IBOutlet weak var btn9: UIButton!
    @IBOutlet weak var lblDisplay: UILabel!
    @IBOutlet weak var btnClear: UIButton!
    @IBOutlet weak var btnResult: UIButton!
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var btnSub: UIButton!
    @IBOutlet weak var btnMulti: UIButton!
    @IBOutlet weak var btnDiv: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btn0Click(_ sender: Any) {
        
    }
    @IBAction func btn1Click(_ sender: Any) {
        
    }
    @IBAction func btn2Click(_ sender: Any) {
        
    }
    @IBAction func btn3Click(_ sender: Any) {
        
    }
    @IBAction func btn4Click(_ sender: Any) {
        
    }
    @IBAction func btn5Click(_ sender: Any) {
        
    }
    @IBAction func btn6Click(_ sender: Any) {
        
    }
    @IBAction func btn7Click(_ sender: Any) {
        
    }
    @IBAction func btn8Click(_ sender: Any) {
        
    }
    @IBAction func btn9Click(_ sender: Any) {
        
    }
    @IBAction func btnAddClick(_ sender: Any) {
        
    }
    @IBAction func btnSubClick(_ sender: Any) {
        
    }
    @IBAction func btnMultiClick(_ sender: Any) {
        
    }
    @IBAction func btnDivClick(_ sender: Any) {
        
    }
    @IBAction func btnClearClick(_ sender: Any) {
        
    }
    @IBAction func btnResultClick(_ sender: Any) {
        
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    
    
}
