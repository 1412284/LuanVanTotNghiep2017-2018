//
//  AvatarEffect.h
//  DemoKara
//
//  Created by Hoang Thuan on 1/31/18.
//  Copyright © 2018 Hoang Thuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface AvatarEffect : CAReplicatorLayer
@property (nonatomic, assign) BOOL shouldResume;
@property (nonatomic, assign) CGFloat fromValueForRadius;
@property (nonatomic, assign) CGFloat keyTimeForHalfOpacity;
@property (nonatomic, assign) NSTimeInterval animationDuration;
@property (nonatomic, assign) NSTimeInterval pulseInterval;
@property (nonatomic, assign) BOOL useTimingFunction;
@property (nonatomic, assign) CGFloat radius;
@property (nonatomic, assign) NSInteger haloLayerNumber;
@property (nonatomic, assign) NSTimeInterval startInterval;
@property (nonatomic, strong) CALayer *effect;
@property (nonatomic, strong) CAAnimationGroup *animationGroup;
@property (nonatomic, weak) CALayer *prevSuperlayer;
@property (nonatomic, assign) unsigned int prevLayerIndex;
@property (nonatomic, strong) CAAnimation *prevAnimation;
- (void)start;
- (void)show;
- (void)hide;

@end
