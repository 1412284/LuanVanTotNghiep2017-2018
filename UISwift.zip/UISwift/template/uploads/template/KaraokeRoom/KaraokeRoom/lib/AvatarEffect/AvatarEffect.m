//
//  AvatarEffect.m
//  DemoKara
//
//  Created by Hoang Thuan on 1/31/18.
//  Copyright © 2018 Hoang Thuan. All rights reserved.
//

#import "AvatarEffect.h"

#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 100000
@interface AvatarEffect () <CAAnimationDelegate>
#else
@interface AvatarEffect ()
#endif

//@property (nonatomic, assign) BOOL shouldResume;
//@property (nonatomic, assign) CGFloat fromValueForRadius;
//@property (nonatomic, assign) CGFloat keyTimeForHalfOpacity;
//@property (nonatomic, assign) NSTimeInterval animationDuration;
//@property (nonatomic, assign) NSTimeInterval pulseInterval;
//@property (nonatomic, assign) BOOL useTimingFunction;
//@property (nonatomic, assign) CGFloat radius;
//@property (nonatomic, assign) NSInteger haloLayerNumber;
//@property (nonatomic, assign) NSTimeInterval startInterval;
//
//@property (nonatomic, strong) CALayer *effect;
//@property (nonatomic, strong) CAAnimationGroup *animationGroup;
//@property (nonatomic, weak) CALayer *prevSuperlayer;
//@property (nonatomic, assign) unsigned int prevLayerIndex;
//@property (nonatomic, strong) CAAnimation *prevAnimation;

@end

@implementation AvatarEffect
@dynamic repeatCount;

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.effect = [CALayer new];
        self.effect.contentsScale = [UIScreen mainScreen].scale;
        self.effect.opacity = 0;
        [self addSublayer:self.effect];
        
        [self _setupDefaults];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(onDidEnterBackground:)
                                                     name:UIApplicationDidEnterBackgroundNotification object:nil];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(onWillEnterForeground:)
                                                     name:UIApplicationWillEnterForegroundNotification object:nil];
    }
    return self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)_setupDefaults {
    _shouldResume = YES;
    _fromValueForRadius = 0.0;
    _keyTimeForHalfOpacity = 0.2;
    _animationDuration = 8;
    _pulseInterval = 0;
    _useTimingFunction = YES;
    
    self.repeatCount = INFINITY;
    self.radius = 120;
    self.haloLayerNumber = 10;
    self.startInterval = 1;
    self.backgroundColor = [[UIColor colorWithRed:1.0
                                            green:1.0
                                             blue:1.0
                                            alpha:1.0] CGColor];
}

- (void)_setupAnimationGroup {
    CAAnimationGroup *animationGroup = [CAAnimationGroup animation];
    animationGroup.duration = self.animationDuration + self.pulseInterval;
    animationGroup.repeatCount = self.repeatCount;
    if (self.useTimingFunction) {
        CAMediaTimingFunction *defaultCurve = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault];
        animationGroup.timingFunction = defaultCurve;
    }
    
    CABasicAnimation *scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale.xy"];
    scaleAnimation.fromValue = @(self.fromValueForRadius);
    scaleAnimation.toValue = @1.0;
    scaleAnimation.duration = self.animationDuration;
    
    CAKeyframeAnimation *opacityAnimation = [CAKeyframeAnimation animationWithKeyPath:@"opacity"];
    opacityAnimation.duration = self.animationDuration;
    CGFloat fromValueForAlpha = CGColorGetAlpha(self.backgroundColor);
    opacityAnimation.values = @[@(fromValueForAlpha), @(fromValueForAlpha * 0.5), @0];
    opacityAnimation.keyTimes = @[@0, @(self.keyTimeForHalfOpacity), @1];
    
    NSArray *animations = @[scaleAnimation, opacityAnimation];
    
    animationGroup.animations = animations;
    
    self.animationGroup = animationGroup;
    self.animationGroup.delegate = self;
}

- (void)onDidEnterBackground:(NSNotification *)notification {
    self.prevSuperlayer = self.superlayer;
    if (self.prevSuperlayer) {
        unsigned int layerIndex = 0;
        for (CALayer *aSublayer in self.superlayer.sublayers) {
            if (aSublayer == self) {
                self.prevLayerIndex = layerIndex;
                break;
            }
            layerIndex++;
        }
    }
    self.prevAnimation = [self.effect animationForKey:@"pulse"];
}

- (void)onWillEnterForeground:(NSNotification *)notification {
    if (self.shouldResume) {
        [self _resume];
    }
}

- (void)_resume {
    [self addSublayer:self.effect];
    [self.prevSuperlayer insertSublayer:self atIndex:self.prevLayerIndex];
    if (self.prevAnimation) {
        [self.effect addAnimation:self.prevAnimation forKey:@"pulse"];
    }
}

- (void)start {
    [self _setupAnimationGroup];
    [self.effect addAnimation:self.animationGroup forKey:@"pulse"];
    [self hide];
}

- (void)show {
    self.hidden = NO;
}

- (void)hide {
    self.hidden = YES;
}

- (void)setBackgroundColor:(CGColorRef)backgroundColor {
    [super setBackgroundColor:backgroundColor];
    self.effect.backgroundColor = backgroundColor;
}

- (void)setRadius:(CGFloat)radius {
    _radius = radius;
    
    CGFloat diameter = self.radius * 2;
    
    self.effect.bounds = CGRectMake(0, 0, diameter, diameter);
    self.effect.cornerRadius = self.radius;
}

- (void)setHaloLayerNumber:(NSInteger)haloLayerNumber {
    _haloLayerNumber = haloLayerNumber;
    self.instanceCount = haloLayerNumber;
    self.instanceDelay = (self.animationDuration + self.pulseInterval) / haloLayerNumber;
}

- (void)setStartInterval:(NSTimeInterval)startInterval {
    _startInterval = startInterval;
    self.instanceDelay = startInterval;
}

- (void)setRepeatCount:(float)repeatCount {
    [super setRepeatCount:repeatCount];
    self.animationGroup.repeatCount = repeatCount;
}

#pragma mark - CAAnimationDelegate

- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag {
    if ([self.effect.animationKeys count]) {
        [self.effect removeAllAnimations];
    }
    [self.effect removeFromSuperlayer];
    [self removeFromSuperlayer];
}

@end
