//
//  UserAvatarEffect.m
//  KaraokeRoom
//
//  Created by CPU11197-local on 5/7/18.
//  Copyright © 2018 CPU11197-local. All rights reserved.
//

#import "UserAvatarEffect.h"

@interface UserAvatarEffect ()
@property (strong, nonatomic) IBOutlet UIView *backgroundViewContainer;

@end
@implementation UserAvatarEffect

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(instancetype)initWithCoder:(NSCoder *)aDecoder {
    
    self = [super initWithCoder:aDecoder];
    if (self){
        [self customInit];
    }
    return self;
}

-(instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self){
        [self customInit];
    }
    return self;
}

-(void)customInit {
    [[NSBundle mainBundle] loadNibNamed:@"UserAvatarEffect" owner:self options:nil];
    [self addSubview:_backgroundViewContainer];
}

-(void)layoutSubviews {
       _backgroundViewContainer.frame = self.bounds;
       _backgroundViewContainer.userInteractionEnabled = YES;
    _avatarImg.frame = CGRectMake(CGRectGetWidth(self.bounds)/4, CGRectGetWidth(self.bounds)/4, CGRectGetWidth(self.bounds)/2, CGRectGetWidth(self.bounds)/2);
    _avatarImg.layer.cornerRadius = CGRectGetWidth(_avatarImg.bounds)/2;
    _avatarImg.layer.masksToBounds = YES;
    _avatarImg.layer.zPosition = 1.0;
       [self addEffectToView];
       [self onAnimationAvatarImg];
}
-(void)addEffectToView{
    [self.backgroundViewContainer.layer addSublayer:self.effect];
    self.effect.position = self.backgroundViewContainer.center;
    [_effect start];
}
-(void)onAnimationAvatarImg{
    _avatarImg.frame = CGRectMake(CGRectGetWidth(self.bounds)/4, CGRectGetWidth(self.bounds)/4, CGRectGetWidth(self.bounds)/2, CGRectGetWidth(self.bounds)/2);
    _avatarImg.layer.cornerRadius = CGRectGetWidth(_avatarImg.bounds)/2;
    double delayInSeconds = 1.0;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [UIView animateWithDuration:1 delay:0 options:UIViewAnimationOptionCurveLinear  animations:^{
            //code with animation
            _avatarImg.frame = _backgroundViewContainer.frame;
            _avatarImg.layer.cornerRadius = CGRectGetWidth(_avatarImg.bounds)/2;
        } completion:^(BOOL finished) {
            //code for completion
            [self onStartEffect];
        }];
        
    });
}
-(void)setAvatarImgWithImgNamed:(NSString*)imgName{
    _avatarImg.image = [UIImage imageNamed:imgName];
}
-(void)setHiddenAvatarImg:(BOOL)hidden{
        _avatarImg.hidden = hidden;
    if(hidden == YES){
        [self onAnimationAvatarImg];
    }
}
-(void)onStartEffect{
    [_effect show];
}
-(void)onStopEffect{
    [_effect hide];
}
- (AvatarEffect *)effect {
    if (_effect == nil) {
        _effect = [AvatarEffect layer];
        _effect.animationDuration = 6;
        _effect.haloLayerNumber = 8;
        _effect.fromValueForRadius = 0.0;
        _effect.backgroundColor = [UIColor blueColor].CGColor;
        _effect.radius = 125;
    }
    return _effect;
    
}

@end
