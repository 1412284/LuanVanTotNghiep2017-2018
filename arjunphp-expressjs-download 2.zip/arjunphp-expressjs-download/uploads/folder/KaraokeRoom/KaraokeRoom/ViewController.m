//
//  ViewController.m
//  KaraokeRoom
//
//  Created by CPU11197-local on 5/7/18.
//  Copyright © 2018 CPU11197-local. All rights reserved.
//

#import "ViewController.h"
#import "UserAvatarEffect.h"

@interface ViewController ()
@property (strong,nonatomic) UserAvatarEffect *avatarEffect;
@property (weak, nonatomic) IBOutlet UIButton *btnAvatar;
@property (weak, nonatomic) IBOutlet UIButton *btnEffect;

//@property (strong,nonatomic) UserAvatarEffect *avatar;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
       self.btnAvatar.selected = NO;
      _avatarEffect = [self.view viewWithTag:100];
     //self.view.backgroundColor = [[UIColor blackColor]colorWithAlphaComponent:0.6];
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)viewDidAppear:(BOOL)animated{
//    _avatar = [[UserAvatarEffect alloc] initWithFrame:CGRectMake(10, 10,100, 100)];;
//     [self.view addSubview:_avatar];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onChangeHiddenAvatarImg:(id)sender {
    if([sender isSelected]){
        [_avatarEffect setHiddenAvatarImg:NO];
        _btnAvatar.selected = NO;
        NSLog(@"isSelected");
    } else{
        [_avatarEffect setHiddenAvatarImg:YES];
         _btnAvatar.selected = YES;
         NSLog(@"No isSelected");
        
    }
}
- (IBAction)onChangeStateEffect:(id)sender {
    if([sender isSelected]){
        [_avatarEffect onStartEffect];
        _btnEffect.selected = NO;
        NSLog(@"isSelected");
    } else{
         [_avatarEffect onStopEffect];
        _btnEffect.selected = YES;
        NSLog(@"No isSelected");
        
    }
}


@end
