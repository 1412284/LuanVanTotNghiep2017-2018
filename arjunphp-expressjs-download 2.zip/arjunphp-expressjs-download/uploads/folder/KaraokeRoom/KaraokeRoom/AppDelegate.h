//
//  AppDelegate.h
//  KaraokeRoom
//
//  Created by CPU11197-local on 5/7/18.
//  Copyright © 2018 CPU11197-local. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

